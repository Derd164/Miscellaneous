#include <iostream>
#include <cmath>

using namespace std;



int main()
{
srand(time(0));

    
    int i;
    int j;
    
    for (j = 0; j < 10; j++) {
        int ttldebt = 0;
        int ttlprofit = 0;
        
        for (i=0; i < 300; i++) {
    
            long long bet$ = 20;
            long long debt = 0;
            long long profit = 0;
            
            
            while (true) {
                int chance = 1 + rand() % (38);
                
                if (chance <= 17.5) {
                    profit = bet$ - debt;
                //    cout << "You won. Your profit is $" << profit << endl;
                    ttlprofit = ttlprofit + profit;
                    break;
                
                }
                
                else if (chance > 17.5) {
                    debt = bet$ + debt;
                 //   cout << "You lost. Your debt is $" << debt << endl;
    
                }
            
            bet$ = bet$*2;
                if (bet$ >= 400) {
                  //  cout << "You have exceeded the limit. Your debt is $" << debt << endl;
                    ttldebt = ttldebt + debt;
                    break;
                }
          //  cout << "Now you bet $" << bet$ << endl;
    
            }
        }
            cout << "Your netprofit is $" << ttlprofit - ttldebt << endl;
    }

    return 0;
}
