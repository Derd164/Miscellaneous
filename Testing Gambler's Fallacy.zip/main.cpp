#include <iostream>
#include <cmath>

using namespace std;



int main()
{
srand(time(0));

    while (true) {

        cout << "How much you wanna bet? ";
        long long bet$;
        cin >> bet$;
        long long debt = 0;
        
        
        while (true) {
            int chance = 1 + rand() % (100);
            
            if (chance <= 48) {
                cout << "You won. Your profit is $" << bet$ - debt << endl;
                break;
            
            }
            
            else if (chance > 48) {
                debt = bet$ + debt;
                cout << "You lost. Your debt is $" << debt << endl;

            }
        
        bet$ = bet$*2;
        cout << "Now you bet $" << bet$ << endl;

        }
    }

    return 0;
}